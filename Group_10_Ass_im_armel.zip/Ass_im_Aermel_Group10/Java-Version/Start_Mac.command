#!/bin/bash
cd "$(dirname "$0")"
if ! command -v java >/dev/null 2>&1; then
  echo "Java wurde nicht gefunden. Bitte Java 17 oder neuer installieren: https://adoptium.net"
  read -p "Enter zum Beenden..."
  exit 1
fi
java -jar Kartenduell.jar
