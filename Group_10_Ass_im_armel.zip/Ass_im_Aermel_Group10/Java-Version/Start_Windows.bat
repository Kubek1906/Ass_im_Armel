@echo off
chcp 65001 >nul
title Ass im Aermel - Group 10
cd /d "%~dp0"
where java >nul 2>nul
if errorlevel 1 (
  echo Java wurde nicht gefunden. Bitte Java 17 oder neuer installieren: https://adoptium.net
  pause
  exit /b
)
java -Dfile.encoding=UTF-8 -jar Kartenduell.jar
echo.
pause
